import { ReservationsPagePage } from "./ReservationsPage";

export default ReservationsPagePage;
