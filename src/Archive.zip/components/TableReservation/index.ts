import {TableReservation} from './TableReservation'

export default TableReservation;