export const USER_UID = "USER_UID";
export const USER_EMAIL = "USER_EMAIL";
export const USER_SESSION_ROLE = "USER_SESSION_ROLE";
